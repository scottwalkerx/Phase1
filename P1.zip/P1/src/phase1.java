import java.util.*;
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException; 
import java.util.stream.IntStream; 
import java.io.PrintWriter;



public class phase1 {

	public static void main(String[] args) throws Exception {
	System.out.println("\t \t \t Welcome to LockedMe"); // Greeting msg
	System.out.println("\t \t \t Developed by Scott Walker");
	
	 Scanner myObj = new Scanner(System.in);  // Create a Scanner object to get name
	    System.out.println("Enter username: ");
	
	    String userName = myObj.next();  // Read user input and assign it to username
	    System.out.println("Hello " + userName.substring(0, 1).toUpperCase() + userName.substring(1)); // prints name in uppercase
	    System.out.println("Welcome to LockedMe.");  // Greeting 
	    
	//    String directoryName;
	//    File dir = new File(directoryName);
	    String[] files = new String[3]; // creating an array of 3 file names 
	   	    
	    Scanner input = new Scanner(System.in); // get user file names
	    System.out.print("Lets create 3 files and name them.\n ");
	    
	    System.out.print("Name of the first file: \n");
	    files[0] = input.next(); // assigning 1st file name to 1st element
	    File file1 = new File (files[0]); // creating 1st file and assigning it to 1st array element
	    
	    System.out.print("Name of the second file: \n");
	    files[1] = input.next(); // assigning 2nd file name to 2nd element
	    File file2 = new File (files[1]); // creating 2nd file and assigning it to 2nd array element
	    
	    System.out.print("Name of the third file: \n");
	    files[2] = input.next(); // assigning 3rd file name to 3rd element
	    File file3 = new File (files[2]); // creating 3rd file and assigning it to 3rd array element
	    
	  //Sorting technique to retrieve the file names in ascending order
	    Arrays.sort(files);
	    System.out.println("Here are the file names in ascending order: ");
        for(int i = 0; i < files.length; i++)
            System.out.println(files[i] + ".txt");
	    
	    System.out.println("Choose a file to write to by entering in the number of the file (1-3): ");
	    Scanner x = new Scanner(System.in); // scanner obj to get file selection
	    String fileText = "";
	    int y = x.nextInt() -1; // subtract 1 b/c array elmnt starts @0
	     PrintWriter writer = null; //creating a writer obj to write to files
	     try {
	    	 writer = new PrintWriter(files[y]);
	    	 System.out.println("Begin writing to " + files[y]); // show user what file they're writing to
	    {
	    	fileText = x.next();	// read in input and writing to file    	
	    	writer.write(fileText); // writing input to desired file
	    };
	     
	     } catch (FileNotFoundException e) {
	    	 e.printStackTrace();
	     }
	   writer.close(); // close file  

        
	    System.out.println("Awesome work. \n If you would like to delete a file, "
	    		+ "enter the number of the desired file to delete (1-3): "
	    		+ "\n Otherwise enter 4 to return back to main menu."
	    		+ "\n Or select 5 to close the app. ");
	    //option to close the current execution context and return to the main context
	    
    	Scanner del = new Scanner(System.in);
    	int  options =  del.nextInt();
        for(int j=1;j<=files.length;j++){
        	if(options==j){
                switch (options){
                case 1:
               	      file1.delete();
                	System.out.println(" The file " + file1 +" was deleted");
                	  break;
                case 2:
          	      file2.delete();
          	System.out.println(" The file " + file2 +" was deleted \n Returning to main menu...");
          	  break;
                case 3:
          	      file3.delete();
          	System.out.println(" The file " + file3 +" was deleted \n Returning to main menu...");
          	break;
                case 4:
            	System.out.println("Returning to main menu ");          	
          	  break;
                case 5:
                	System.out.println("Closing the application \n");
                	System.exit(0);
                default:
                    System.out.println("You have made an invalid choice!");
                    break;                	    
                 }
        	} 
        	
        	}
        
	}
	
	// THE BLOCK BELOW IS A METHOD USED TO SEARCH THRU THE FILES WITH THE SPECIFIED CRITERIA
	    Scanner search = new Scanner(System.in); // scanner obj to get file selection
	 public void parseFile(String fileName,String searchStr) throws FileNotFoundException{
	        Scanner scan = new Scanner(new File(fileName));
	        while(scan.hasNext()){
	            String line = scan.nextLine().toLowerCase().toString();
	            if(line.contains(searchStr)){
	                System.out.println(line);
	            }
	        }
	    }
	
	}
 
