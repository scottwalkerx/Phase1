import java.util.*;
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException; 
import java.util.stream.IntStream; 
import java.io.PrintWriter;



public class phase1 {

	public static void main(String[] args) throws Exception {
	System.out.println("                         Welcome to LockedMe"); // Greeting msg
	System.out.println("Developed by Scott Walker");
	
	 Scanner myObj = new Scanner(System.in);  // Create a Scanner object to get name
	    System.out.println("Enter username: ");
	
	    String userName = myObj.next();  // Read user input and assign it to username
	    System.out.println("Hello " + userName.substring(0, 1).toUpperCase() + userName.substring(1)); // prints name in uppercase
	    System.out.println("Welcome to LockedMe.");  // Greeting 
	    
	    String directoryName;
	    File dir = new File(directoryName);
	    String[] files = new String[3]; // creating an array of 3 file names 
	   
	    
	    Scanner input = new Scanner(System.in); // get user file names
	    System.out.print("Lets create 3 files and name them.\n ");
	    
	    System.out.print("Name of the first file: \n");
	    files[0] = input.next(); // assigning 1st file name to 1st element
	    File file1 = new File (files[0]); // creating 1st file and assigning it to 1st array element
	    
	    System.out.print("Name of the second file: \n");
	    files[1] = input.next(); // assigning 2nd file name to 2nd element
	    File file2 = new File (files[1]); // creating 2nd file and assigning it to 2nd array element
	    
	    System.out.print("Name of the third file: \n");
	    files[2] = input.next(); // assigning 3rd file name to 3rd element
	    File file3 = new File (files[2]); // creating 3rd file and assigning it to 3rd array element
	    
	  //Sorting technique to retrieve the file names in ascending order
	    Arrays.sort(files);
	    System.out.println("Here are the file names in ascending order: ");
        for(int i = 0; i < files.length; i++)
            System.out.println(files[i] + ".txt");
	    
	    System.out.println("Choose a file to write to by entering in the number of the file (1-3): ");
	    Scanner x = new Scanner(System.in); // scanner obj to get file selection
	    String fileText = "";
	    int y = x.nextInt() -1; // subtract 1 b/c array elmnt starts @0
	     PrintWriter writer = null; //creating a writer obj to write to files
	     try {
	    	 writer = new PrintWriter(files[y]);
	    	 System.out.println("Begin writing to " + files[y]); // show user what file they're writing to
	    {
	    	fileText = x.next();	// read in input and writing to file    	
	    	writer.write(fileText); // writing input to desired file
	    };
	     
	     } catch (FileNotFoundException e) {
	    	 e.printStackTrace();
	     }
	   writer.close(); // close file  

        
	    System.out.println("Awesome work. \n If you would like to delete a file, enter the number of the desired file to delete (1-3) : "
	    		+ "\n Otherwise enter N to return back to main menu. ");
	    //option to close the current execution context and return to the main context
    	Scanner del = new Scanner(System.in);
    	File d = new File (files[x]); // take in user input of Y or N
    	for (int x=0; x<files.length; x++)
    	d = del.next();
    	switch (d) {
    	case "1":
    		files[0].delete();
    	case "2":
    		files[1].delete();
    	case "3":
    		files[2].delete();

    	}
    		
    	else if(d == "y")
    	{
       int num = del.nextInt(); 
        if(files[num-1].delete()) // delete the file
        else if del.equals('N');
        return;
    
    	}
        
	}
	
	// THE BLOCK BELOW IS A METHOD USED TO SEARCH THRU THE FILES WITH THE SPECIFIED CRITERIA
	System.out.println("Enter the string you would like to find within the files created: ");
	Scanner find = new Scanner(System.in);
	String f = find.next();
	String line = "";
	int i;
	try { FileInputStream fin = new FileInputStream(files[i]) //use file array as obj to search
		Scanner x = new Scanner(fin);
	while(x.hasNextLine())	 {
		line=x.nextLine();
		if(line.startsWith(f))
			System.out.println(line);
	}
	}
        
	    
	    
	}
	    
	    
	   //  File file = new File(fileName1);
	   // boolean isFileCreated;
		//try { //create new file and let user know if it was created
	//	isFileCreated = file.createNewFile();
	//		System.out.print("File: " + fileName1 + " was created succesfully and added to the directory. ");
	//	} catch (IOException e) { // incase it fails
	//		// TODO Auto-generated catch block
	//		e.printStackTrace();
	//	} 
		//
	 
	    
	
	    
	    
	    
	    
	

